let gameResult = document.getElementById("gameResult");
let userInput = document.getElementById("userInput");
let random_num = Math.ceil(Math.random() * 100);

console.log(random_num);

function checkGuess() {
    let guessNumber = parseInt(userInput.value);
    console.log(guessNumber);
    //=== exactly compare == in js 2='2' give true as it does't comapre type but === does
    if (random_num === guessNumber) {
        gameResult.textContent = "Congratulations! You got it right.";
        gameResult.style.backgroundColor = "green";
    } else if (random_num < guessNumber) {
        gameResult.textContent = "Too High! Try Again.";
        gameResult.style.backgroundColor = "#1e217c";
    } else if (random_num > guessNumber) {
        gameResult.textContent = "Too low! Try Again.";
        gameResult.style.backgroundColor = "#1e217c";
    } else {
        gameResult.textContent = "Provide a valid user input.";
        gameResult.style.backgroundColor = "red";
    }

}